<?php
session_start();
if(!isset($_SESSION['loggedin']) ||$_SESSION['loggedin']!=true ){
    header("location:login.php");
    exit();
}
$delete = false;
$update=false;
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <link rel='stylesheet' type='text/css' href='//cdn.datatables.net/1.11.0/css/jquery.dataTables.min.css' />
        <link rel="stylesheet" href="style.css">

    <!-- <script
  src="https://code.jquery.com/jquery-3.6.0.js"
  integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
  crossorigin="anonymous"></script>
     -->

    <title>Hello, world!</title>
</head>

<body  >
    
    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit this Note</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">X</span>
                    </button>
                </div>
                <form action="order.php" method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="snoEdit" id="snoEdit">
                        <div class="form-group">
                            <label for="title">Enter new Name</label>
                            <input type="text" class="form-control" id="titleEdit" name="titleEdit"
                                aria-describedby="emailHelp"></input>
                        </div>

                        <div class="form-group">
                            <label for="desc">Enter new Description</label>
                            <textarea class="form-control" id="descriptionEdit" name="descriptionEdit"
                                rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="desc">Enter new Amount</label>
                            <input type="text" class="form-control" id="amountedit" name="amountedit" rows="3">
                            <div class="form-group">
                                <label for="desc">Upload Image</label>

                                <input type="file" name="image" id="image" rows="3" class="form-control">
                            </div>
                        </div>
                        </input>


                    </div>
                    <div class="modal-footer d-block mr-auto">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
            </div>

            </form>
        </div>
    </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="">Rizwan Sweets Admin Panel</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link " aria-current="page" href="index.php">Add New Item</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="update.php">Update Item</a>
                    <!-- </li>
 <li class="nav-item">
                        <a class="nav-link" href="order.php">Orders</a>
                    </li> -->
                </ul>
                <form class="d-flex" method="post" action="logout.php">
        
                <button class="btn btn-danger" style="background-color:black" type="submit">logout</button>
      </form>
            </div>
        </div>
    </nav>


    <div class="container mt-3">
        <table class="table table-responsive" id="myTable">
            <thead>
                <tr>
                    <th scope="col">S.no</th>
                    <th scope="col">Name</th>
                    <th scope="col">order</th>
                    <th scope="col">Amount</th>
                    <th scope="col">Date</th>
                    <th scope="col">Email</th>
                    <th scope="col">Address</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- php section -->
                <?php
    include 'connectiondb.php';
if(!$conn){
die("Sorry we are unable to connect you to database bacuse: ".mysqli_connect_error());
}
else{
    
    if(isset($_GET['delete'])){
  $sno = $_GET['delete'];
  $delete = true;
  $sql = "DELETE FROM `checkout` WHERE `orderid` = $sno";
  $result = mysqli_query($conn, $sql);
}
if (isset( $_POST['snoEdit'])){
  // Update the record
    $sno = $_POST["snoEdit"];
    $title = $_POST["titleEdit"];
    $description = $_POST["descriptionEdit"];
    $amount=$_POST["amountedit"];
     $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
    $date = date("Y-m-d H:i:s");
    
  // Sql query to be executed
  $sql = "UPDATE `additem` SET `name` = '$title' , `description` = '$description',  `amount` = '$amount' , `date` = '$date', `picture`= '$file'  WHERE `id` = '$sno'";
  $result = mysqli_query($conn, $sql);
  if($result){
    $update = true;
}
else{
    echo "We could not update the record successfully";
}
}
}
$sql= "SELECT * FROM `checkout`";

$result=mysqli_query($conn,$sql);
$num=mysqli_num_rows($result);

while($row =mysqli_fetch_assoc($result)){
  
 echo'   <tr>

 
      <th scope="row">.'.$row['orderid'] .'</th>
      <td>'.$row['cusname'].'</td>
      <td>'.$row['itemname'].'</td>
      <td>'.$row['tamount'].'</td>
      <td>'.$row['date'].'</td>
      <td>'.$row['customeremail'].'</td>
      <td>'.$row['customeraddress'].'</td>
      <td>'.$row['phone'].'</td>
    
      <td> <button class="delete btn btn-sm btn-primary btn-success" name=delete id=d'.$row['orderid'].'>Finish</button></td>
   
    </tr>';
}


    ?>
            </tbody>
        </table>
    </div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script>
      
    $(document).ready(function() {
        $('#myTable').DataTable();

    });
  
    </script>
    <script>
    // edits = document.getElementsByClassName('edit');
    // Array.from(edits).forEach((element) => {
    //     element.addEventListener("click", (e) => {
    //         console.log("edit ");
    //         tr = e.target.parentNode.parentNode;
    //         title = tr.getElementsByTagName("td")[0].innerText;
    //         description = tr.getElementsByTagName("td")[1].innerText;
    //         amount = tr.getElementsByTagName("td")[2].innerText;
    //         picture = tr.getElementsByTagName("td")[4].innerText;
    //         console.log(title, description, amount, picture);
    //         titleEdit.value = title;
    //         descriptionEdit.value = description;
    //         amountedit.value = amount;
    //         // picture.value = picture;
    //         snoEdit.value = e.target.id;
    //         console.log(e.target.id)
    //         $('#editModal').modal('toggle');
    //     })
    // })

    deletes = document.getElementsByClassName('delete');
    Array.from(deletes).forEach((element) => {
        element.addEventListener("click", (e) => {
            console.log("edit ");
            sno = e.target.id.substr(1);

            if (confirm("Are you sure you want to remove this order!")) {
                console.log("yes");
                window.location = `/php/web/adminpanel/order.php?delete=${sno}`;
                // TODO: Create a form and use post request to submit a form
            } else {
                console.log("no");
            }
        })
    })
    </script>

</body>

</html>
<script>
$(document).ready(function() {
    $('#btnsubmit').click(function() {
        var image_name = $('#image').val();
        if (image_name == '') {
            alert("Please Select Image");
            return false;
        } else {
            var extension = $('#image').val().split('.').pop().toLowerCase();
            if (jQuery.inArray(extension, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
                alert('invalid image file');
                $('#image').val('');
                return false;
            }
        }
    });
});
</script>