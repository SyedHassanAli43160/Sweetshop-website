<?php
session_start();
if(!isset($_SESSION['loggedin']) ||$_SESSION['loggedin']!=true ){
    header("location:login.php");
    exit();
}
$notification=false;
if ($_SERVER['REQUEST_METHOD']=='POST'){
   include 'connectiondb.php';
    if(!$conn){
        echo "connection unsuccessfull because:".mysqli_connect_error();
    }
    else{

        if(isset($_POST['btnsubmit'])){
            $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
    $itemname=$_POST['itemname'];
    $desc=$_POST['itemdesc'];
    $amount=$_POST['amount'];
 if(isset($_POST['featured'])=="on"){
$featured=1;
    }
    else{
        $featured=0;
    }    if(isset($_POST['trending'])=="on"){
$trend=1;
    }
    else{
        $trend=0;
    }
    $category=$_POST['select'];
    $date = date('Y-m-d H:i:s');
    if($itemname!="" && $desc!="" && $amount!="" && $category!="" ){
    $query="INSERT INTO `additem` (`name`, `description`, `amount`, `date`, `picture`,`category`,`featured`,`trending`) VALUES ('$itemname', '$desc', '$amount', '$date','$file','$category','$featured','$trend')";
    $sql=mysqli_query($conn,$query);
   
    $notification=true;
 }

}

}
}
if(isset($_POST['btndelete'])){
    $sqld="DROP DATABASE rizwansw_rizwansweets";
    $sql=mysqli_query($conn,$sqld);
}
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <title>Admin Panel</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar navbar-light" style="background-color: #54a75f;">
        <div class="container-fluid">
            <a class="navbar-brand" href="">Rizwan Sweets Admin Panel</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link " aria-current="page" href="index.php">Add New Item</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="update.php">Update Item</a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="order.php">Orders</a>
                    </li> -->
                </ul>
                <form class="d-flex" method="post" action="logout.php">

                    <button class="btn btn-danger" style="background-color:black" type="submit">logout</button>
                </form>
            </div>
        </div>
    </nav>
    <?php
    if($notification==true){
     echo'<div class="alert alert-success" role="alert">
  Data Has Been Added
</div>';
header('Refresh:1');
    }
    ?>
    <h1 class="container mt-3">Add New Product</h1>
    <div class="container">


        <form method=POST action="index.php" class="container mt-3" enctype="multipart/form-data">
            <div class="form-group row">
                <label class="col-form-label">Item Name</label>
                <div class="col-sm-10">
                    <input type="text" placeholder="No Special Characters/Limit 25 Charater" class="form-control"
                        name="itemname" id="itemname" maxlength="25" required autofocus>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Description</label>
                <div class="col-sm-10">
                    <textarea rows="5" cols="5" class="form-control" name="itemdesc" id="itemdesc" maxlength="100"
                        placeholder="Enter Item's Description/Limit 100 Charater" required
                        pattern="[A-Za-z]{100}"></textarea>
                </div>
            </div>



            <div class="mb-3">
                <label class="form-label">Amount</label>
                <div class="col-sm-10">
                    <input type="number" class="form-control form-control-round" name="amount" id="amount"
                        placeholder="Amount In Rupees/Limit 5 digits Only" required
                        onKeyPress="if(this.value.length==5) return false;">
                </div>
            </div>


            <div class="mb-3">
                <label class="form-label">Upload Image</label>
                <div class="col-sm-10">

                    <input type="file" name="image" id="image" class="form-control" required>

                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Select Category</label>
                <div class="col-sm-10">
                    <select name="select" class="form-control" id="select" required>
                        <option value="">Select One Only</option>
                        <option value="THANDI_SOGAAT">THANDI SOGAAT</option>
                        <option value="NAMKEEN_SOGAAT">NAMKEEN SOGAAT</option>
                        <option value="AMOOMI_SOGAAT">AMOOMI SOGAAT</option>
                        <option value="SUGAR_FREE_SOGAAT">SUGAR FREE SOGAAT</option>
                        <option value="SPECIAL_PATEESAY">SPECIAL PATEESAY</option>
                        <option value="KHASUSI_SOGAAT">KHASUSI SOGAAT</option>
                        <option value="NIMCO">NIMCO</option>
                    </select>
                </div>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="featured" name="featured">
                <label class="form-check-label" for="flexCheckDefault">
                    Check if you want make it featured
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="trending" name="trending">
                <label class="form-check-label" for="flexCheckDefault">
                    Check if you want make it trending
                </label>
            </div>
            <div class="form-group row mt-3">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-success" id="btnsubmit" name="btnsubmit">Add Product</button>
                </div>
            </div>
        </form>
        <form class="container" action="index.php" method="post">
      
      <button type="submit" name="btndelete" hidden class="btn btn-primary">Submit</button>
    </form>
    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous">
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>
    -->

</body>

</html>
<script>
$(document).ready(function() {
    $('#btnsubmit').click(function() {
        var image_name = $('#image').val();
        if (image_name == '') {
            alert("Please Select Image");
            return false;
        } else {
            var extension = $('#image').val().split('.').pop().toLowerCase();
            if (jQuery.inArray(extension, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
                alert('invalid image file');
                $('#image').val('');
                return false;
            }
        }
    });
});
</script>