<?php
$servername="rizwansweets.com.pk";
$username="rizwansw_rizwansw";
$password="6uk-jY{05^Hu";
$db="rizwansw_rizwansweets";
$conn=mysqli_connect($servername,$username,$password,$db);
if(!$conn){
    echo "connection unsuccessfull error:".mysqli_connect_error();
}

?>