<?php
session_start();
if(!isset($_SESSION['loggedin']) ||$_SESSION['loggedin']!=true ){
    header("location:login.php");
    exit();
}
$delete = false;
$update=false;
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <!-- 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous"> -->
    <link rel='stylesheet' type='text/css' href='//cdn.datatables.net/1.11.2/css/jquery.dataTables.min.css' />
    <link rel="stylesheet" href="https://cdn.datatables.net/rowreorder/1.2.8/css/rowReorder.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
    <!-- <script
  src="https://code.jquery.com/jquery-3.6.0.js"
  integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
  crossorigin="anonymous"></script>
     -->

    <title>Admin Panel</title>
</head>

<body>

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit this Product</h5>
                    <!-- <button type="button" onclick="closeModal()" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">X</span>
                    </button> -->
                </div>
                <form action="update.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="snoEdit" id="snoEdit">
                        <div class="form-group">
                            <label for="title">Enter new Name</label>
                            <input type="text" class="form-control" id="titleEdit" name="titleEdit" maxlength="25"
                                aria-describedby="emailHelp" required autofocus></input>
                        </div>

                        <div class="form-group">
                            <label for="desc">Enter new Description</label>
                            <textarea class="form-control" id="descriptionEdit" name="descriptionEdit" maxlength="500"
                                required rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="desc">Enter new Amount</label>
                            <input type="number" class="form-control" id="amountedit" name="amountedit" rows="3"
                                required onKeyPress="if(this.value.length==5) return false;">
                            </input>
                        </div>
                        <div class="form-group">
                            <label for="desc">Add New Picture</label>

                            <input type="file" name="image" id="image" class="form-control" required>
                            </input>
                        </div>

                    </div>
                    <div class="modal-footer d-block mr-auto">
                        <button type="button" class="btn btn-secondary" onclick="closeModal()"
                            data-dismiss="modal">Cancel</button>
                        <button type="submit" name="btnpicture" id="btnpicture" class="btn btn-primary">Save
                            changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <nav class="navbar navbar-expand-lg navbar navbar-light" style="background-color: #54a75f;">
        <div class="container-fluid">
            <a class="navbar-brand" href="">Rizwan Sweets Admin Panel</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link " aria-current="page" href="index.php">Add New Item</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="update.php">Update Item</a>
                        <!-- </li>
 <li class="nav-item">
                        <a class="nav-link" href="order.php">Orders</a>
                    </li> -->
                </ul>
                <form class="d-flex" method="post" action="logout.php">

                    <button class="btn btn-danger" style="background-color:black" type="submit">logout</button>
                </form>
            </div>
        </div>
    </nav>


    <div class="container mt-3">
        <table class="display nowrap" style="width:100%" id="myTable">
            <!-- <caption>Product Table</caption> -->
            <thead>
                <tr>
                    <th>S.no</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Picture</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- php section -->
                <?php
    include 'connectiondb.php';
if(!$conn){
die("Sorry we are unable to connect you to database bacuse: ".mysqli_connect_error());
}
else{
    
    if(isset($_GET['delete'])){
  $sno = $_GET['delete'];
  $delete = true;
  $sql = "DELETE FROM `additem` WHERE `id` = $sno";
  $result = mysqli_query($conn, $sql);
}
if (isset($_POST['snoEdit'])){
  // Update the record
    $sno = $_POST["snoEdit"];
    $title = $_POST["titleEdit"];
    $description = $_POST["descriptionEdit"];
    $amount=$_POST["amountedit"];
$picture=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));;
   
    
  // Sql query to be executed
  $sql = "UPDATE `additem` SET `name` = '$title' , `description` = '$description',  `amount` = '$amount' , `date` = now(), `picture`='$picture' WHERE `id` = '$sno' ";
  $result = mysqli_query($conn, $sql);
  if($result){
    $update = true;
}
else{
    echo "We could not update the record successfully";
}
}
}
$sql= "SELECT * FROM `additem`";
$num=0;
$result=mysqli_query($conn,$sql);


while($row =mysqli_fetch_assoc($result)){
    // $num=mysqli_num_rows($result);
    $num+=1;
 
 echo' 
 <th scope="row">'.$num.'</th>
      <td>'.$row['name'].'</td>
      <td>'.$row['description'].'</td>
      <td>'.$row['amount'].'</td>
      <td>'.$row['date'].'</td>
      
      <td name="picture" id="picture"> <img  style="width:100px; height:50px"src="data:image/jpeg;base64,'.base64_encode($row['picture']).'"></td>
  
    
      <td> <a class=" edit btn btn-sm btn-primary "
      onclick="editFunc(\'' .$row['id']. '\',\'' .$row['name']. '\',\'' .$row['description']. '\',\'' .$row['amount']. '\')"  id='.$row['id'].'>Edit</a> 
      <button class="delete btn btn-sm btn-primary btn-danger" onclick="deleteFunc('.$row['id'].')" name="delete" id=d'.$row['id'].'>Delete</button></td>
   
    </tr>';
}


    ?>
            </tbody>
            <!-- <tfoot>
                <tr>
                    <th>S.no</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Picture</th>
                    <th>Action</th>
                </tr>
            </tfoot> -->
        </table>
    </div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous">
    </script>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
    <script src="//cdn.datatables.net/1.11.2/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/rowreorder/1.2.8/js/dataTables.rowReorder.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script>
    // $(document).ready(function() {
    //     edits = document.getElementsByClassName('edit');
    //     Array.from(edits).forEach((element) => {
    //         element.addEventListener("click", (e) => {

    //             tr = e.target.parentNode.parentNode;
    //             title = tr.getElementsByTagName("td")[0].innerText;
    //             description = tr.getElementsByTagName("td")[1].innerText;
    //             amount = tr.getElementsByTagName("td")[2].innerText;
    //             picture = tr.getElementsByTagName("td")[4].innerText;

    //             titleEdit.value = title;
    //             descriptionEdit.value = description;
    //             amountedit.value = amount;
    //             // picture.value = picture;
    //             snoEdit.value = e.target.id;

    //             $('#editModal').modal('toggle');
    //         })
    //     });
    // });

    // deletes = document.getElementsByClassName('delete');

    // Array.from(deletes).forEach((element) => {
    //     element.addEventListener("click", (e) => {
    //         console.log("delete pressed");
    //         sno = e.target.id.substr(1);

    //         if (confirm("Are you sure you want to remove this order!")) {
    //             console.log("yes");
    //             window.location = `/php/newrizwan1/adminpanel/update.php?delete=${sno}`;
    //             // TODO: Create a form and use post request to submit a form
    //         } else {
    //             console.log("no");
    //         }
    //     })
    // });
    function editFunc(id, name, description, amount) {

        // console.log(id);
        // console.log(name);
        //console.log(id);
        titleEdit.value = name;
        descriptionEdit.value = description;
        amountedit.value = amount;

        snoEdit.value = id;

        $('#editModal').modal('toggle');

    }

    function closeModal() {

        $('#editModal').modal('toggle');
    }

    function deleteFunc(sno) {


        if (confirm("Are you sure you want to remove this order!")) {
            console.log("yes");
            window.location = `/php/newrizwan1/adminpanel/update.php?delete=${sno}`;
            // TODO: Create a form and use post request to submit a form
        } else {
            console.log("no");
        }

    }
    </script>

    <script>
    // $(document).ready(function() {
    //     $('#myTable').DataTable();

    // });
    $(document).ready(function() {
        var table = $('#myTable').DataTable({
            rowReorder: {
                selector: 'td:nth-child(2)'
            },
            responsive: true
        });
    });
    </script>

</body>

</html>
<script>
$(document).ready(function() {
    $('#btnpicture').click(function() {
        var image_name = $('#image').val();
        if (image_name == '') {
            alert("Please Select Image");
            return false;
        } else {
            var extension = $('#image').val().split('.').pop().toLowerCase();
            if (jQuery.inArray(extension, ['gif', 'png', 'jpg', 'jpeg', 'jfif']) == -1) {
                alert('invalid image file');
                $('#image').val('');
                return false;
            }
        }
    });
});
</script>