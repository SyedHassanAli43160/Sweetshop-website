let galleryItems=document.querySelector(".gallery-items").children; 
let prev=document.querySelector(".prev");
 let next=document.querySelector(".next");
 let page=document.querySelector(".page-num");
 let maxItem=6;
 let index=1;
 

  prev.addEventListener("click",function(){
    index--;
    check();
    showItems();
  })
  next.addEventListener("click",function(){
  	index++;
  	check();
    showItems();  
  })

  function check(){
	  let value=Math.round(galleryItems.length/maxItem);
	let pagination=Math.ceil(value);
  	 if(index==pagination){
  	 	next.classList.add("disabled");
  	 }
  	 else{
  	   next.classList.remove("disabled");	
  	 }

  	 if(index==1){
  	 	prev.classList.add("disabled");
  	 }
  	 else{
  	   prev.classList.remove("disabled");	
  	 }
  }

  function showItems() {
  	 for(let i=0;i<galleryItems.length; i++){
  	 	galleryItems[i].classList.remove("show");
  	 	galleryItems[i].classList.add("hide");


  	    if(i>=(index*maxItem)-maxItem && i<index*maxItem){
  	 	  // if i greater than and equal to (index*maxItem)-maxItem;
  		  // means  (1*8)-8=0 if index=2 then (2*8)-8=8
          galleryItems[i].classList.remove("hide");
          galleryItems[i].classList.add("show");
  	    }
  	    page.innerHTML=index;
  	 }	
  }
  function showItemsAgain() {
	  var again=8;
  	 for(let i=0;i<again; i++){
  	 	galleryItems[i].classList.remove("show");
  	 	galleryItems[i].classList.add("hide");
		

  	    if(i>=(index*maxItem)-maxItem && i<index*maxItem){
          galleryItems[i].classList.remove("hide");
          galleryItems[i].classList.add("show");
  	    }
  	    page.innerHTML=index;
  	 }	
  }
function loadItems(){
	showItems();
  	check();
}
//   window.onload=function(){
//   	loadItems();
//   }

$("#searchInput").keyup(function() {
        // Retrieve the input field text and reset the count to zero
        var filter = $(this).val(),
            count = 0;
        // Loop through the comment list

        $('#page_details div').each(function() {
            // If the list item does not contain the text phrase fade it out
            if ($(this).text().search(new RegExp(filter, "i")) < 0) {
				hideThis(this);
            } else {
                
				showThis(this);	
                count++;
            }
	

        });
		if(filter==""){
		showItems();
		}
    });
function hideThis(item){
	item.classList.add("hide");
	item.classList.remove("show");
}

function showThis(item){
	item.classList.add("show");
	item.classList.remove("hide");
}