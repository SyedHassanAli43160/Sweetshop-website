<?php
include 'connectiondb.php';
?>
<!DOCTYPE html>
<html lang="zxx">


<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rizwan Sweets</title>

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&amp;display=swap"
        rel="stylesheet">
<link rel="stylesheet" href="slideshow only css/sliderstyle.css" />
    <link rel="stylesheet" href="css/myStyle.css" type="text/css" />
</head>

<body>

    <div id="preloder">
        <div class="loader"></div>
    </div>

    <div class="humberger__menu__overlay"></div>
    <div class="humberger__menu__wrapper">
        <div class="humberger__menu__logo">
            <a href="#"><img src="logo.png" alt=""></a>
        </div>
        <!-- <div class="humberger__menu__cart">
            <ul>
                <li><a href="#"><i class="fa fa-heart"></i> <span>1</span></a></li>
                <li><a href="#"><i class="fa fa-shopping-bag"></i> <span>3</span></a></li>
            </ul>
            <div class="header__cart__price">item: <span>$150.00</span></div>
        </div> -->
        <div class="humberger__menu__widget">
            <div class="header__top__right__language">
                <img src="img/xlanguage.png.pagespeed.ic.x-r7SQqGJF.jpg" alt="">
                <div>English</div>
                <span class="arrow_carrot-down"></span>
                <ul>
                   
                    <li><a href="#">English</a></li>
                </ul>
            </div>
         
        </div>
        <nav class="humberger__menu__nav mobile-menu">
            <ul>
                <li class="active"><a href="#">Home</a></li>
                <li><a href="shop-grid.php" onclick="load_page_details()">Shop</a></li>
              
                <li><a href="contact.html">Contact</a></li>
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="header__top__right__social">
            <a href="https://www.facebook.com/rizwansweetspk/?ref=page_internal"><i class="fa fa-facebook"></i></a>
            <a
                href="https://www.instagram.com/rizwansweetspk/?fbclid=IwAR2yoCm_Wm5sWE6sGFjy70t0KeuRJ9r-dY7a_4hvUTTdvnXQJ8toXyEatuU"><i
                    class="fa fa-instagram"></i></a>

        </div>
        <div class="humberger__menu__contact">
            <ul>
                <li><i class="fa fa-envelope"></i> <a class="__cf_email__">Info@rizwansweets.com.pk</a></li>
                <li>Shipping Not Available Yet</li>
            </ul>
        </div>
    </div>


    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="header__top__left">
                            <ul>
                                <li><i class="fa fa-envelope"></i> <a
                                        class="__cf_email__">Info@rizwansweets.com.pk</a>
                                </li>
                                <li>Shipping Not Available Yet</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="header__top__right">
                            <div class="header__top__right__social">
                                <a href="https://www.facebook.com/rizwansweetspk/?ref=page_internal"><i
                                        class="fa fa-facebook"></i></a>
                                <a
                                    href="https://www.instagram.com/rizwansweetspk/?fbclid=IwAR2yoCm_Wm5sWE6sGFjy70t0KeuRJ9r-dY7a_4hvUTTdvnXQJ8toXyEatuU"><i
                                        class="fa fa-instagram"></i></a>
                                <!-- <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-pinterest-p"></i></a> -->
                            </div>
                            <div class="header__top__right__language">
                                <img src="img/xlanguage.png.pagespeed.ic.x-r7SQqGJF.jpg" alt="">
                                <div>English</div>
                                <span class="arrow_carrot-down"></span>
                                <ul>
                                  
                                    <li><a href="#">English</a></li>
                                </ul>
                            </div>

                            <!-- <div class="header__top__right__auth">
                                <a href="#"><i class="fa fa-user"></i> Login</a>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="header__logo">
                        <a href="index-2.html"><img src="logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="header__menu">
                      <center>
                      <ul>
                            <li class="active"><a href="#">Home</a></li>
                            <li><a href="shop-grid.php" onclick="load_page_details('')">Shop</a></li>
                           
                        
                            <li><a href="contact.html">Contact</a></li>
                        </ul>

                      </center>
                    </nav>
                </div>
                <div class="col-lg-3" style="padding-top: 20px;">
                    <div class="hero__search__phone">
                        <div class="hero__search__phone__icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="hero__search__phone__text">
                            <h5>+92 300 0283764</h5>
                            <span>support 24/7 time</span>
                        </div>
                    </div>
                </div>
                <div class="humberger__open">
                    <i class="fa fa-bars"></i>
                </div>
            </div>
    </header>


    <section class="hero">

        </div>
        <!-- <div class="hero__item set-bg" data-setbg="img/hero/banner1.jpg">
            <div class="hero__text" style="text-align: left;">
            <h2>Rizwan</h2>   
            <span style="color:black; font-style: italic; ">Sweets & Bakers<br />100% Organic Products</span>
               
                <p>Where You Find The Real Taste</p>
                <a href="shop-grid.php" class="primary-btn btn-danger">SHOP NOW</a>
            </div>
        </div> -->
        <div class="hero__item set-bg" >
        <div class="slidershow middle">

<div class="slides">
  <input type="radio" name="r" id="r1" checked>
  <input type="radio" name="r" id="r2">
  <input type="radio" name="r" id="r3">
  <input type="radio" name="r" id="r4">
  <input type="radio" name="r" id="r5">
  <div class="slide s1">
    <img src="slideshow only css/1.jpg" alt="">
  </div>
  <div class="slide">
    <img src="slideshow only css/2.jpg" alt="">
  </div>
  <div class="slide">
    <img src="slideshow only css/3.jpg" alt="">
  </div>
  <div class="slide">
    <img src="slideshow only css/4.jpg" alt="">
  </div>
  <div class="slide">
    <img src="slideshow only css/5.jpg" alt="">
  </div>
</div>

<div class="navigation">
  <label for="r1" class="bar"></label>
  <label for="r2" class="bar"></label>
  <label for="r3" class="bar"></label>
  <label for="r4" class="bar"></label>
  <label for="r5" class="bar"></label>
</div>
</div>
            </div>
    


      

    </section>
    <div class="col-lg-12">
        <div class="section-title">
            <h2>Trending Product</h2>
        </div>
    </div>

    <section class="categories">
        <div class="container">
            <div class="row">
                <div class="categories__slider owl-carousel">

                    <?php
                       $sql= "SELECT * FROM `additem` WHERE trending=1";
                    $result=mysqli_query($conn,$sql);      
                   
				while($items =mysqli_fetch_assoc($result)){

                   echo' <div class="col-lg-3">
                  
                   <div class="categories__item set-bg" data-setbg="data:image/jpeg;base64,'.base64_encode($items['picture']).'">
                                      
                            <h5><a href="#">'.$items['name'].'</a></h5>
                        </div>
                    </div>'; 
                    
                                 }?>



                </div>
            </div>
        </div>
    </section>


    <section class="featured spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Featured Product</h2>
                    </div>
                    <div class="featured__controls">
                        <ul>
                            <li class="active" data-filter="*">All</li>
                            <li data-filter=".NIMCO">NIMCO</li>
                            <li data-filter=".NAMKEEN_SOGAAT">NAMKEEN SOGAAT</li>
                            <li data-filter=".AMOOMI_SOGAAT">AMOOMI SOGAAT</li>
                            <li data-filter=".KHASUSI_SOGAAT">KHASUSI SOGAAT</li>
                            <li data-filter=".SPECIAL_PATEESAY">SPECIAL PATEESAY</li>
                            <li data-filter=".SUGAR_FREE_SOGAAT">SUGAR-FREE SOGAAT</li>
                            <li data-filter=".THANDI_SOGAAT">THANDI SOGAAT</li>

                        </ul>
                    </div>
                </div>
            </div>
            <!-- while() -->
            <div class="row featured__filter">
                <?php
    $sql= "SELECT * FROM `additem` WHERE featured=1";
                    $result=mysqli_query($conn,$sql);      
                   
				while($items =mysqli_fetch_assoc($result)){
          $clas=$items['category'];
          echo'
                <div class="col-lg-3 col-md-4 col-sm-6 mix '.$clas.' ">               
                    <div class="featured__item">
                        <div class="featured__item__pic set-bg" data-setbg="data:image/jpeg;base64,'.base64_encode($items['picture']).'">
                            <ul class="featured__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="#">'.$items['name'].'</a></h6>
                            <h5>'.$items['amount'].'</h5>
                        </div>
                    </div>
                </div>
';
        }
?>




            </div>
        </div>
    </section>


    <div class="banner1">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="banner1__pic">
                        <img src="img/banner1/xbanner1-1.jpg.pagespeed.ic.-NRyTdVwji.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="banner1__pic">
                        <img src="img/banner1/xbanner1-2.jpg.pagespeed.ic.pSCK_iOvxr.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>








    <footer class="footer spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer__about">
                        <div class="footer__about__logo">
                            <a href="index.php"><img src="logo.png" alt=""></a>
                        </div>
                        <ul>
                            <li>R/40, main Landhi Rd, 1.5 Gulzar Colony Sector 32 B Korangi, Karachi, Karachi City, Sindh, Pakistan</li>
                            <li>Phone:+92 300 0283764</li>
                            <li><i></i> <a class="__cf_email__">Info@rizwansweets.com.pk</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-1">
                    <div class="footer__widget">
                        <h6>Useful Links</h6>
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="shop-grid.php">Shop</a></li>
                            <li><a href="#">Contact</a></li>
                         

                        </ul>
                   
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="footer__widget">
                        <h6>Contact Us By Click Below</h6>
                        <div class="footer__widget__social">
                            <a href="https://www.facebook.com/rizwansweetspk/?ref=page_internal"><i
                                    class="fa fa-facebook"></i></a>
                            <a
                                href="https://www.instagram.com/rizwansweetspk/?fbclid=IwAR2yoCm_Wm5sWE6sGFjy70t0KeuRJ9r-dY7a_4hvUTTdvnXQJ8toXyEatuU"><i
                                    class="fa fa-instagram"></i></a>


                        </div>
                        <p></p>
                        <p></p>
                        <p>Through Whatsapp You Can Reach Us Instantly!</p>


                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer__copyright">
                        <div class="footer__copyright__text">
                            <p>
                                Copyright <script>
                                document.write(new Date().getFullYear());
                                </script> All rights reserved | RizwanSweets <i class="fa fa-heart"
                                    aria-hidden="true"></i> by <a href="#" target="_blank">Softmesh Solution</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js%2bjquery.nice-select.min.js.pagespeed.jc.08NHUfMhux.js"></script>
    <script>
    eval(mod_pagespeed_ND6iIrfFHB);
    </script>
    <script>
    eval(mod_pagespeed_2CR7bSFHcL);
    </script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>


    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-23581568-13');
    </script>
    <script defer src="js/beacon.min.js"
        data-cf-beacon='{"rayId":"68fa614fab4617df","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2021.8.1","si":10}'>
    </script>
    <a href="https://wa.me/++923000283764?" class="float" style="
  position: fixed;
  width: 50px;
  height: 50px;
  bottom: 20px;
  right: 20px;
  color: #fff;
  border-radius: 50px;
  text-align: center;
  cursor: pointer;
  box-shadow: 2px 2px 3px #999;
">
        <img src="https://trickuweb.com/whatsapp.png" alt="" height="50px" width="50px" />
    </a>
</body>


</html>