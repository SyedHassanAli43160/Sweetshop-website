<?php
include 'connectiondb.php';

?>
<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from preview.colorlib.com/theme/ogani/shop-grid.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 16 Sep 2021 13:18:46 GMT -->

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shop | RizwanSweets</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&amp;display=swap"
        rel="stylesheet">
    <link href="css/table.css" rel="stylesheet">
    <link rel="stylesheet" href="css/myStyle.css" type="text/css" />
    <link rel="stylesheet" href="css/Pagination_style.css" type="text/css">
    <style>

    </style>
</head>

<body>

    <div id="preloder">
        <div class="loader"></div>
    </div>

    <div class="humberger__menu__overlay"></div>
    <div class="humberger__menu__wrapper">
        <div class="humberger__menu__logo">
            <a href="#"><img src="logo.png" alt=""></a>
        </div>
        <div class="humberger__menu__cart">
            <!-- <ul>
                <li><a href="#"><i class="fa fa-heart"></i> <span>1</span></a></li>
                <li><a href="#"><i class="fa fa-shopping-bag"></i> <span>3</span></a></li>
            </ul> -->
            <!-- <div class="header__cart__price">item: <span>$150.00</span></div> -->
        </div>
        <div class="humberger__menu__widget">
            <div class="header__top__right__language">
                <img src="img/xlanguage.png.pagespeed.ic.x-r7SQqGJF.jpg" alt="">
                <div>English</div>
                <span class="arrow_carrot-down"></span>
                <ul>
                    <!-- <li><a href="#">Spanis</a></li> -->
                    <li><a href="#">English</a></li>
                </ul>
            </div>
            <!-- <div class="header__top__right__auth">
                <a href="#"><i class="fa fa-user"></i> Login</a>
            </div> -->
        </div>
        <nav class="humberger__menu__nav mobile-menu">
            <ul>
                <li class="active"><a href="index.php">Home</a></li>
                <li><a href="shop-grid.php">Shop</a></li>
                <!-- <li><a href="#">Pages</a>
                    <ul class="header__menu__dropdown">
                        <li><a href="shop-details.html">Shop Details</a></li>
                        <li><a href="shoping-cart.html">Shoping Cart</a></li>
                        <li><a href="checkout.html">Check Out</a></li>
                        <li><a href="blog-details.html">Blog Details</a></li>
                    </ul>
                </li> -->
                <!-- <li><a href="blog.html">Blog</a></li> -->
                <li><a href="contact.html">Contact</a></li>
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="header__top__right__social">
            <a href="https://www.facebook.com/rizwansweetspk/?ref=page_internal"><i class="fa fa-facebook"></i></a>
            <a
                href="https://www.instagram.com/rizwansweetspk/?fbclid=IwAR1gJIFB2J16yjUzBQXBCMIlOfti7IV-5Fsooz-RbE0wtBT6cvSi5Aj4ji0"><i
                    class="fa fa-instagram"></i></a>

        </div>
        <div class="humberger__menu__contact">
            <ul>
                <li><i class="fa fa-envelope"></i> <a class="__cf_email__">Info@rizwansweets.com.pk</a></li>
                <li>Shipping Not Available Yet</li>
            </ul>
        </div>
    </div>


    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="header__top__left">
                            <ul>
                                <li><i class="fa fa-envelope"></i> <a
                                        class="__cf_email__">Info@rizwansweets.com.pk</a>
                                </li>
                                <li>Shipping Not Available Yet</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="header__top__right">
                            <div class="header__top__right__social">
                                <a href="https://www.facebook.com/rizwansweetspk/?ref=page_internal"><i
                                        class="fa fa-facebook"></i></a>
                                <a
                                    href="https://www.instagram.com/rizwansweetspk/?fbclid=IwAR1gJIFB2J16yjUzBQXBCMIlOfti7IV-5Fsooz-RbE0wtBT6cvSi5Aj4ji0"><i
                                        class="fa fa-instagram"></i></a>

                            </div>
                            <div class="header__top__right__language">
                                <img src="img/xlanguage.png.pagespeed.ic.x-r7SQqGJF.jpg" alt="">
                                <div>English</div>
                                <span class="arrow_carrot-down"></span>
                                <ul>

                                    <li><a href="#">English</a></li>
                                </ul>
                            </div>
                            <!-- <div class="header__top__right__auth">
                                <a href="#"><i class="fa fa-user"></i> Login</a>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="header__logo">
                        <a href="index.php"><img src="logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="header__menu">
                      <center>
                      <ul>
                            <li><a href="index.php">Home</a></li>
                            <li class="active"><a href="shop-grid.php">Shop</a></li>
                       
                            <li><a href="contact.html">Contact</a></li>
                        </ul>

                      </center>
               
                    </nav>
                </div>
                <div class="col-lg-3">
<div class="header__cart">
  <div class="hero__search__phone">
    <div class="hero__search__phone__icon">
        <i class="fa fa-phone"></i>
    </div>
    <div class="hero__search__phone__text">
        <h5>+92 300 0283764</h5>
        <span>support 24/7 time</span>
    </div>
</div>
</div>
</div>
               
            </div>
            <div class="humberger__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>


    <section class="hero hero-normal">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="hero__categories">
                        <div class="hero__categories__all">
                            <i class="fa fa-bars"></i>
                            <span>Categories</span>
                        </div>
                        <ul>
                        <li><a href="#" onclick=" load_page_details()">ALL CATEGORIES</a></li>

<li><a href="#" onclick=" load_page_details('THANDI_SOGAAT')">THANDI SOGAAT</a></li>
<li><a href="#" onclick=" load_page_details('NAMKEEN_SOGAAT')">NAMKEEN SOGAAT</a></li>
<li><a href="#" onclick=" load_page_details('AMOOMI_SOGAAT')">AMOOMI SOGAAT</a></li>
<li><a href="#" onclick=" load_page_details('SUGAR_FREE_SOGAAT')">SUGAR FREE SOGAAT</a>
</li>
<li><a href="#" onclick=" load_page_details('SPECIAL_PATEESAY')">SPECIAL PATEESAY</a>
</li>
<li><a href="#" onclick=" load_page_details('NIMCO')">NIMCO</a></li>
<li><a href="#" onclick=" load_page_details('KHASUSI_SOGAAT')"> KHASUSI SOGAAT</a></li>

                        </ul>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="hero__search">
                        <div class="hero__search__form">
                            <form action="#">

                                <input type="text" id="searchInput" placeholder="What do yo u need?">

                            </form>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>




    <section class="product spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-5">
                    <div class="sidebar">
                        <div class="sidebar__item">
                            <h4>Categories</h4>
                            <ul class="nav navbar-nav">


                                <li><a href="#" onclick=" load_page_details()">ALL CATEGORIES</a></li>

                                <li><a href="#" onclick=" load_page_details('THANDI_SOGAAT')">THANDI SOGAAT</a></li>
                                <li><a href="#" onclick=" load_page_details('NAMKEEN_SOGAAT')">NAMKEEN SOGAAT</a></li>
                                <li><a href="#" onclick=" load_page_details('AMOOMI_SOGAAT')">AMOOMI SOGAAT</a></li>
                                <li><a href="#" onclick=" load_page_details('SUGAR_FREE_SOGAAT')">SUGAR FREE SOGAAT</a>
                                </li>
                                <li><a href="#" onclick=" load_page_details('SPECIAL_PATEESAY')">SPECIAL PATEESAY</a>
                                </li>
                                <li><a href="#" onclick=" load_page_details('NIMCO')">NIMCO</a></li>
                                <li><a href="#" onclick=" load_page_details('KHASUSI_SOGAAT')"> KHASUSI SOGAAT</a></li>

                            </ul>

                        </div>
                        <div class="sidebar__item">
                          
                        </div>
                        <div class="sidebar__item sidebar__item__color--option">
                          
                        </div>
                        <div class="sidebar__item">
                          
                        </div>
                        <div class="sidebar__item">
                          
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 col-md-7">
                    <div class="section-title product__discount__title">
                        <h2>Our Products</h2>
                    </div>
                  

                    <div class="gallery">
                  <center>
                    <div id='loader' style='display: none;'>
  <img src='img/green_style.gif' width='32px' height='32px'>
</div>
</center>
                        <div id="page_details" class=" row gallery-items">
                       
<!-- Image loader -->

                        </div>




                        <div class="pagination">
                            <button class="prev site-btn">Prev</button>
                            <button class="page site-btn " disabled>Page <span class="page-num"></span></button>
                            <button class="next site-btn">Next</button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        </div>
    </section>


    <footer class="footer spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer__about">
                        <div class="footer__about__logo">
                            <a href="index.php"><img src="logo.png" alt=""></a>
                        </div>
                        <ul>
                            <li>R/40, main Landhi Rd, 1.5 Gulzar Colony Sector 32 B Korangi, Karachi, Karachi City, Sindh, Pakistan</li>
                            <li>Phone:+92 300 0283764</li>
                            <li><i></i> <a class="__cf_email__">Info@rizwansweets.com.pk</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-1">
                    <div class="footer__widget">
                        <h6>Useful Links</h6>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="#">Shop</a></li>
                            <li><a href="contact.html">Contact</a></li>
                     

                        </ul>
                   
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="footer__widget">
                        <h6>Contact Us By Click Below</h6>
                        <div class="footer__widget__social">
                            <a href="https://www.facebook.com/rizwansweetspk/?ref=page_internal"><i
                                    class="fa fa-facebook"></i></a>
                            <a
                                href="https://www.instagram.com/rizwansweetspk/?fbclid=IwAR2yoCm_Wm5sWE6sGFjy70t0KeuRJ9r-dY7a_4hvUTTdvnXQJ8toXyEatuU"><i
                                    class="fa fa-instagram"></i></a>


                        </div>
                        <p></p>
                        <p></p>
                        <p>Through Whatsapp You Can Reach Us Instantly!</p>


                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer__copyright">
                        <div class="footer__copyright__text">
                            <p>
                                Copyright <script>
                                document.write(new Date().getFullYear());
                                </script> All rights reserved | RizwanSweets <i class="fa fa-heart"
                                    aria-hidden="true"></i> by <a href="#" target="_blank">Softmesh Solution</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <script>
    function load_page_details(category) {
        $.ajax({
            url: "fetch.php",
            method: "POST",
            data: {
                category: category
            },
            beforeSend: function(){
    // Show image container
    $("#loader").show();
   },
            success: function(data) {
                $('#page_details').html(data);
                loadItems();
            },
            complete:function(data){
    // Hide image container
    $("#loader").hide();
   }
        });

    }
    </script>
    <script src="js/script.js"></script>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js%2bjquery.nice-select.min.js.pagespeed.jc.08NHUfMhux.js"></script>
    <script>
    eval(mod_pagespeed_ND6iIrfFHB);
    </script>
    <script>
    eval(mod_pagespeed_2CR7bSFHcL);
    </script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <!-- <script src="js/table.js"></script> -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-23581568-13');
    </script>
    <script defer src="js/beacon.min.js"
        data-cf-beacon='{"rayId":"68fa6151ff5b17e3","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2021.8.1","si":10}'>
    </script>
    <script>
    $(document).ready(function() {

        $.ajax({
            url: load_page_details(),
            success: function() {

            }
        })
    });
    </script>

    <a href="https://wa.me/+923332207100?" class="float" ; target="_blank" ; style="
  position: fixed;
  width: 50px;
  height: 50px;
  bottom: 20px;
  right: 20px;
  color: #fff;
  border-radius: 50px;
  text-align: center;
  cursor: pointer;
  box-shadow: 2px 2px 3px #999;
">
        <img src="https://trickuweb.com/whatsapp.png" alt="" height="50px" width="50px" />
    </a>
</body>


</html>